#ifndef TRYDDATAPROCESS_H
#define TRYDDATAPROCESS_H

#include <QString>
#include <QVector>

enum Ativos {
    DOL,
    WDO,
    IND,
    WIN,
    VALE3,
    PETR4,
    ITUB4,
    BBDC4,
    ABEV3,
    B3SA3,
    WEGE3
};

#define tamAtivo 11

struct SeparadorDadosResult {
    int sizeChange;
    int ativo;
};

class trydDataProcess
{
public:
    /*
    Função principal para processar todos dados recebidos no secket.
    A função salva os dados em uma struct dentro da classe e disponibiliza
    publicamente os valores atraves de dadosTT. Os valores são empilhados
    em um vetor e podem ser manipulados como vetores.
    */
    QVector<bool> processaDados(QString* msg);
    int processaDadosInt(QString* msg); //dados internacionais

    /*
    wxString ativo é o ativo a ser solicitado, negs solicita dados do TT,
    boff solicita dados do book fechado, pBoof é a profundidade do book fechado
    */
    QString solicitaDados(QString ativo, QString tipo, int pBoff = 3);

    /*
    Solicita dados do TT e retorna um wxString com data, lote, preco e agressor
    sizeChage é quantos negocios serão solicitados. Os negocios solicitados contam
    serão os ultimos sizeChange.
    */
    QString getPrintTT(int sizeChange, int ativo);

    /*
    Solicita dados do Book fechado e retorna um wxString com lote e preco
    deeph é a profundidade solicitada.
    */
    QString getPrintBF(int deeph, int ativo);

    /*
    Solicita um print da cotação de determinado ativo
    */
    QString getPrintCOT(int ativo);



private:
    Ativos ativoToNum(const QString& str) {
        QString aux = str.mid(0,3);
        if (aux == "WDO") return WDO;
        if (aux == "wdo") return WDO;
        if (aux == "DOL") return DOL;
        if (aux == "dol") return DOL;
        if (aux == "IND") return IND;
        if (aux == "WIN") return WIN;
        if (str == "VALE3") return VALE3;
        if (str == "PETR4") return PETR4;
        if (str == "ITUB4") return ITUB4;
        if (str == "BBDC4") return BBDC4;
        if (str == "ABEV3") return ABEV3;
        if (str == "B3SA3") return B3SA3;
        if (str == "WEGE3") return WEGE3;
        return DOL; // Caso padrão
    }



    int separador_dados_BK(QString* msg);
    SeparadorDadosResult separador_dados_TT(QString* msg);
    int separador_dados_COT(QString* msg);

public:
    int sizeTTChange[tamAtivo];

    struct dataTT {
        int negocio;
        QString datetime;
        double preco;
        int lote;
        int Ag_comprador;
        int Ag_vendedor;
        QString Agressor;
    };

    QVector<dataTT> dadosTT[tamAtivo];

    struct dataBOOKF {
        int loteComprador;
        double precoComprador;
        double precoVendedor;
        int loteVendedor;
    };

    QVector<dataBOOKF> dadosBF[tamAtivo];

    struct dataCOT {
        double ultima;
        double variacao;
        int bid_lote;
        double bid;
        double ask;
        int ask_lote;
        double abertura;
        double maxima;
        double minima;
        double fechamento;
        double volume;
        QString hora;
        QString estatus;
        double variacao_p;
        QString horario_leilao;
    };

    dataCOT dadosCOT[tamAtivo];


    struct dataCOTint {
        double ultima;
        double variacao;
    };

    QVector<dataCOTint> dadosCOTSp;
    QVector<dataCOTint> dadosCOTDx;
    QVector<dataCOTint> dadosCOTOuro;
    QVector<dataCOTint> dadosCOTWti;


public:
    QVector<dataBOOKF> getBook(int deeph, int ativo);
    QVector<dataTT> getTT(int positon, int len);

};

#endif // TRYDDATAPROCESS_H
