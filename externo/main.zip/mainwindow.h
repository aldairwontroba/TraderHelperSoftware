
#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QtWidgets>
#include <QMainWindow>
#include <QTcpSocket>
#include <QTcpServer>
#include <QTextEdit>
#include <QSettings>

#include <qmath.h>

#include <QtCore/QMetaObject>
#include <QtCore/QDateTime>

#include <QtCharts/QCandlestickSet>
#include <QtCharts/QBarCategoryAxis>
#include <QtCharts/QChartView>
#include <QtCharts/QCandlestickSeries>
#include <QtCharts/QValueAxis>


#include "trydDataProcess.h"



QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MyJanelaTTDialog : public QDialog
{
    Q_OBJECT

public:
    MyJanelaTTDialog(QWidget *parent = nullptr) : QDialog(parent) {

        QVBoxLayout *layout = new QVBoxLayout;

        textEditTT = new QTextEdit(this);
        textEditBF = new QTextEdit(this);
        textEditBF->setFixedSize(400, 160);

        layout->addWidget(textEditTT);
        layout->addWidget(textEditBF);

        setLayout(layout);
        setWindowTitle("Times & Trades");
        resize(400, 600);

    }

    QTextEdit *textEditTT;
    QTextEdit *textEditBF;

};

class MyJanelaMSGDialog : public QDialog
{
    Q_OBJECT

public:
    MyJanelaMSGDialog(QWidget *parent = nullptr) : QDialog(parent) {

        QVBoxLayout *layout = new QVBoxLayout;

        textEditMSG = new QTextEdit(this);

        layout->addWidget(textEditMSG);

        setLayout(layout);
        setWindowTitle("Mensagem Recebida");
        resize(900, 900);

    }

    QTextEdit *textEditMSG;

};


class MainWindow : public QMainWindow

{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    Ui::MainWindow *ui;

    trydDataProcess tdp;

    void loadSettings();
    void saveSettings();

private slots:
    void on_actionTimer1s_triggered();
    void onTimer1sEvent();

    void on_actionTryd_Connect_triggered();
    void trydConnected();
    void trydDisconnected();
    void trydSocketError();
    void onSocketTrydEvent();

    void on_actionMT5_Connect_triggered();
    void mt5Connected();
    void onSocketMt5Event();

    void on_actionShow_TT_triggered();
    void on_actionShow_Msg_triggered();
    void on_actionShow_Msg_Int_triggered();

    void on_actionDolar_Analiser_triggered();
    void onTimerAnaliserEvent();

    void on_actionSettings_triggered();
    void configok();
    void configcancel();

    void on_actionAnalisador_de_Leil_o_triggered();
    void onTimerLeilaoEvent();

    void on_actionShow_Cota_o_triggered();

private:
    void closeEvent(QCloseEvent *event)
    {
        // Exibe mensagem de confirmação
        QMessageBox::StandardButton resposta = QMessageBox::question(this, "Fechar", "Deseja realmente fechar a janela?", QMessageBox::Yes | QMessageBox::No);

        if (resposta == QMessageBox::Yes) {
            // Aceita o fechamento da janela
            if (janelaTT != nullptr) janelaTT->close();
            if (janelaMSG != nullptr) janelaMSG->close();

            event->accept();
        } else {
            // Cancela o fechamento da janela
            event->ignore();
        }
    }

    QDialog *janela = nullptr;
    QLineEdit* lineEdit;
    QLineEdit* lineEdit_2;

    QTcpSocket tcpTrydClient;
    QTcpServer *tcpMt5Server;

    MyJanelaTTDialog *janelaTT = nullptr;
    MyJanelaMSGDialog *janelaMSG = nullptr;
    MyJanelaMSGDialog *janelaInt = nullptr;
    MyJanelaMSGDialog *janelaCOT = nullptr;

    QTimer *timer1s = nullptr;

    //////////////////////////////////////////////////
    /// Analiser
    QTimer *timerAnaliser = nullptr;
    bool holdTTChange = true;
    QVector<trydDataProcess::dataBOOKF> lastbook;
    QVector<trydDataProcess::dataBOOKF> atualbook;
    int lastTTpos = 0;
    int atualTTpos = 0;
    int lastMinute;
    int totalDeslocamentoV = 0;
    int totalDeslocamentoC = 0;
    qreal highhigh = 0;
    qreal lowlow = 0;
    qreal timestamp = 0;
    qreal open = 0;
    qreal high = 0;
    qreal low = 0;
    qreal close = 0;
    QCandlestickSet *candlestickSet;
    QCandlestickSeries *deslocSeries;
    QChart *chart = nullptr;
    QChartView *chartView;
    QVBoxLayout *lay;
    QValueAxis *axisX;
    QValueAxis *axisY;
    int xInit = 0;
    int xEnd = 60;
    //////////////////////////////////////////////////

    QVector<double> dolar1min;
    QVector<double> indice1min;
    QVector<double> sp1min;
    QVector<double> dx1min;

    //////////////////////////////////////////////////
    /// Leilao
    QTimer *timerLeilao = nullptr;
    QVector<trydDataProcess::dataBOOKF> bookleilao;
};

#endif // MAINWINDOW_H
