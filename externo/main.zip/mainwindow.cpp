#include "mainwindow.h"
#include "ui_mainwindow.h"

#define BOOKDEPH 20
#define numAtivos 11

#define NEGOCIOS "NEGS$S|"
#define BOOKF "LVL2$S|"
#define COTACAO "COT$S|"
#define GRAFICO "GRF$S|"



QString DOLAR = "DOLV23";
QString miniDOLAR = "WDOV23";
QString INDICE = "INDM23";
QString miniINDICE = "WINM23";
QString VALE = "VALE3";
QString PETR = "PETR4";
QString ITUB = "ITUB4";
QString BBDC = "BBDC4";
QString ABEV = "ABEV3";
QString B3SA = "B3SA3";
QString WEGE = "WEGE3";
QString DI24 = "DI1F24";
QString DI25 = "DI1F25";
QString DI26 = "DI1F26";
QString DI27 = "DI1F27";
QString DI29 = "DI1F29";
QString DI31 = "DI1F31";
QString DI33 = "DI1F33";




//////////////////////////////////////////////////////////////////////////////

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    loadSettings();
}
void MainWindow::loadSettings()
{
    // Configurações do arquivo myTradeSettings.ini
    QCoreApplication::setOrganizationName("AWI");
    QCoreApplication::setApplicationName("Trader Helper");

    // Restaurando o estado anterior da janela
    QSettings settings("myTradeSettings.ini", QSettings::IniFormat);
    settings.beginGroup("MainWindow");

    const QByteArray geometry = settings.value("geometry", QByteArray()).toByteArray();
    if (!geometry.isEmpty()) {
        restoreGeometry(geometry);
    }
    const QByteArray state = settings.value("windowState", QByteArray()).toByteArray();
    if (!state.isEmpty()) {
        restoreState(state);
    }
    QString dolaux = settings.value("dolar", QString()).toString();
    if (!dolaux.isEmpty()) {
        DOLAR = dolaux;
        miniDOLAR = settings.value("minidolar", QString()).toString();
        INDICE = settings.value("indice", QString()).toString();
        miniINDICE = settings.value("miniindice", QString()).toString();
    }


}
void MainWindow::saveSettings()
{
    // Salvando o estado atual da janela
    QSettings settings("myTradeSettings.ini", QSettings::IniFormat);
    settings.beginGroup("MainWindow");
    settings.setValue("geometry", saveGeometry());
    settings.setValue("windowState", saveState());
    settings.setValue("dolar", DOLAR);
    settings.setValue("minidolar", miniDOLAR);
    settings.setValue("indice", INDICE);
    settings.setValue("miniindice", miniINDICE);
    settings.endGroup();
}
MainWindow::~MainWindow()
{
    saveSettings();

    delete ui;
}
void MainWindow::on_actionSettings_triggered()
{
    QGridLayout *gridLayout;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QLabel *label;
    QLabel *label_2;

    janela = new QDialog(this);

    janela->setObjectName("JanelaConfig");
    janela->setWindowTitle("Config");
    janela->resize(366, 183);

    gridLayout = new QGridLayout(janela);

    //
    label = new QLabel(janela);
    label->setText("Contrato do Dolar:");

    gridLayout->addWidget(label, 0, 0, 1, 1);

    label_2 = new QLabel(janela);
    label_2->setText("Contrato do Indice:");

    gridLayout->addWidget(label_2, 1, 0, 1, 1);

    //
    lineEdit = new QLineEdit(janela);

    gridLayout->addWidget(lineEdit, 0, 1, 1, 1);
    lineEdit->setText(DOLAR);

    lineEdit_2 = new QLineEdit(janela);

    gridLayout->addWidget(lineEdit_2, 1, 1, 1, 1);
    lineEdit_2->setText(INDICE);

 //
    pushButton = new QPushButton(janela);
    pushButton->setText("OK");

    gridLayout->addWidget(pushButton, 2, 0, 1, 1);

    pushButton_2 = new QPushButton(janela);
    pushButton_2->setText("Cancelar");

    gridLayout->addWidget(pushButton_2, 2, 1, 1, 1);

//
    connect(pushButton, &QPushButton::clicked, this, &MainWindow::configok);
    connect(pushButton_2, &QPushButton::clicked, this, &MainWindow::configcancel);

    janela->show();
}
void MainWindow::configok()
{
    DOLAR = lineEdit->text();
    miniDOLAR = "WDO" + DOLAR.mid(3,3);
    INDICE = lineEdit_2->text();
    miniINDICE = "WIN" + INDICE.mid(3,3);
    janela->close();
}
void MainWindow::configcancel()
{
    janela->close();
}

//////////////////////////////////////////////////////////////////////////////

void MainWindow::on_actionTimer1s_triggered()
{
    if (!ui->actionTimer1s->isChecked()) {
        timer1s->stop();
        return;
    }
    if (timer1s == nullptr){
        timer1s = new QTimer(this);
        timer1s->setInterval(1000); // intervalo de 1 segundo
        QObject::connect(timer1s, &QTimer::timeout, this, &MainWindow::onTimer1sEvent);
    }
    timer1s->start(); // inicia o timer
}
void MainWindow::onTimer1sEvent()
{
    if (tdp.dadosCOT[DOL].ultima == 0) return ui->statusbar->showMessage("Sem dados do Dolar");
    if (tdp.dadosCOT[WIN].ultima == 0) return ui->statusbar->showMessage("Sem dados do Indice");
    if (tdp.dadosCOTSp.empty()) return ui->statusbar->showMessage("Sem dados do SP");
    if (tdp.dadosCOTDx.empty()) return ui->statusbar->showMessage("Sem dados do DX");

    ui->statusbar->clearMessage();

    int N = 10;
    double xmDol = 0;
    double xmInd = 0;
    double xmSp = 0;
    double xmDx = 0;

    double dvpDol = 0;
    double dvpInd = 0;
    double dvpSp = 0;
    double dvpDx = 0;

    double covDolInd = 0;
    double covDolSp = 0;
    double covDolDx = 0;

    double corDolInd = 0;
    double corDolSp = 0;
    double corDolDx = 0;

    dolar1min.push_back(tdp.dadosCOT[DOL].ultima);
    indice1min.push_back(tdp.dadosCOT[WIN].ultima);
    sp1min.push_back(tdp.dadosCOTSp.back().ultima);
    dx1min.push_back(tdp.dadosCOTDx.back().ultima);

    int lastPos = dolar1min.size() - 1;
    if (lastPos > N)
    {
        // calculo das medias

        for (int i = lastPos; i > lastPos-N; i--)
        {
            xmDol += dolar1min[i];
            xmInd += indice1min[i];
            xmSp += sp1min[i];
            xmDx += dx1min[i];
        }
        xmDol = xmDol/N;
        xmInd = xmInd/N;
        xmSp = xmSp/N;
        xmDx = xmDx/N;

        // calculo do desvio padrao

        for (int i = lastPos; i > lastPos-N; i--)
        {
            dvpDol += (dolar1min[i]-xmDol)*(dolar1min[i]-xmDol);
            dvpInd += (indice1min[i]-xmInd)*(indice1min[i]-xmInd);
            dvpSp += (sp1min[i]-xmSp)*(sp1min[i]-xmSp);
            dvpDx += (dx1min[i]-xmDx)*(dx1min[i]-xmDx);
        }
        dvpDol = qSqrt(dvpDol/(N-1));
        dvpInd = qSqrt(dvpInd/(N-1));
        dvpSp = qSqrt(dvpSp/(N-1));
        dvpDx = qSqrt(dvpDx/(N-1));

        // calculo das covariancia

        for (int i = lastPos; i > lastPos-N; i--)
        {
            covDolInd += (dolar1min[i]-xmDol)*(indice1min[i]-xmInd);
            covDolSp += (dolar1min[i]-xmDol)*(sp1min[i]-xmSp);
            covDolDx += (dolar1min[i]-xmDol)*(dx1min[i]-xmDx);
        }
        covDolInd = covDolInd/(N-1);
        covDolSp = covDolSp/(N-1);
        covDolDx = covDolDx/(N-1);

        // calculo da correlação

        corDolInd = covDolInd/(dvpDol*dvpInd);
        corDolSp = covDolSp/(dvpDol*dvpSp);
        corDolDx = covDolDx/(dvpDol*dvpDx);

        QString aux;

        aux.append(QString("CorInd: %1  ").arg(QString::number(corDolInd, 'f', 2)));
        aux.append(QString("CorSp: %1  ").arg(QString::number(corDolSp, 'f', 2)));
        aux.append(QString("CorDx: %1  ").arg(QString::number(corDolDx, 'f', 2)));

        ui->textEdit_1->append(aux);

    }


}

//////////////////////////////////////////////////////////////////////////////

void MainWindow::on_actionTryd_Connect_triggered()
{
    if (ui->actionTryd_Connect->isChecked()) {
        connect(&tcpTrydClient, &QTcpSocket::readyRead, this, &MainWindow::onSocketTrydEvent);
        connect(&tcpTrydClient, &QTcpSocket::connected, this, &MainWindow::trydConnected);
        connect(&tcpTrydClient, &QTcpSocket::disconnected, this, &MainWindow::trydDisconnected);
        connect(&tcpTrydClient, &QTcpSocket::errorOccurred, this, &MainWindow::onSocketTrydEvent);

        tcpTrydClient.connectToHost("localhost",12002);
        ui->textEdit_1->append("Conectando ao tryd...");
    } else {
        tcpTrydClient.disconnectFromHost();
        ui->textEdit_1->append("Desconectando do tryd");
    }
}
void MainWindow::onSocketTrydEvent()
{
    QString msg_print;

    QByteArray recData = tcpTrydClient.readAll();
    QString receivedData = QString::fromUtf8(recData);

    QVector<bool> sizeChange = tdp.processaDados(&receivedData);


    ui->label_Dolar_U->setText(QString("%1").arg(QString::number(tdp.dadosCOT[DOL].ultima, 'f', 2)));
    ui->label_Dolar_V->setText(QString("%1%").arg(QString::number(tdp.dadosCOT[DOL].variacao, 'f', 2)));

    ui->label_miniDolar_U->setText(QString("%1").arg(QString::number(tdp.dadosCOT[WDO].ultima, 'f', 2)));
    ui->label_miniDolar_V->setText(QString("%1%").arg(QString::number(tdp.dadosCOT[WDO].variacao, 'f', 2)));

    ui->label_Indice_U->setText(QString("%1").arg(QString::number(tdp.dadosCOT[IND].ultima, 'f', 0)));
    ui->label_Indice_V->setText(QString("%1%").arg(QString::number(tdp.dadosCOT[IND].variacao, 'f', 2)));

    ui->label_miniIndice_U->setText(QString("%1").arg(QString::number(tdp.dadosCOT[WIN].ultima, 'f', 0)));
    ui->label_miniIndice_V->setText(QString("%1%").arg(QString::number(tdp.dadosCOT[WIN].variacao, 'f', 2)));


    if (!tdp.dadosCOTSp.empty())
    {
        ui->label_Sp_U->setText(QString("%1").arg(QString::number(tdp.dadosCOTSp.last().ultima, 'f', 2)));
        ui->label_Sp_V->setText(QString("%1%").arg(QString::number(tdp.dadosCOTSp.last().variacao, 'f', 2)));
    }
    if (!tdp.dadosCOTDx.empty())
    {
        ui->label_Dx_U->setText(QString("%1").arg(QString::number(tdp.dadosCOTDx.last().ultima, 'f', 2)));
        ui->label_Dx_V->setText(QString("%1%").arg(QString::number(tdp.dadosCOTDx.last().variacao, 'f', 2)));
    }


    if (janelaMSG != nullptr) janelaMSG->textEditMSG->append(receivedData);
    if (janelaCOT != nullptr) janelaCOT->textEditMSG->append(tdp.getPrintCOT(DOL));

    if (janelaTT != nullptr && sizeChange[WDO] == true)
    {
        msg_print = tdp.getPrintTT(tdp.sizeTTChange[WDO], WDO);
        janelaTT->textEditTT->append(msg_print);
        msg_print = tdp.getPrintBF(8, WDO);
        janelaTT->textEditBF->append(msg_print);
    }

//    if (janelaTT != nullptr)
//    {
//        msg_print = tdp.getPrintBF(8, PETR4);
//        janelaTT->textEditBF->append(msg_print);
//    }
}
void MainWindow::trydConnected()
{
    QString msg_send;

    ui->textEdit_1->append("Tryd Conectado via Socket!");
    ui->textEdit_1->append("Solicitando dados do Tryd.");

    for (int i=0;i<numAtivos;i++)
        tdp.dadosBF[i].resize(BOOKDEPH);

    msg_send = tdp.solicitaDados(DOLAR, NEGOCIOS);
    msg_send.append(tdp.solicitaDados(miniDOLAR, NEGOCIOS));
    msg_send.append(tdp.solicitaDados(DOLAR, BOOKF, BOOKDEPH));
    msg_send.append(tdp.solicitaDados(miniDOLAR, BOOKF, BOOKDEPH));

    msg_send.append(tdp.solicitaDados(DOLAR, COTACAO));
    msg_send.append(tdp.solicitaDados(INDICE, COTACAO));
    msg_send.append(tdp.solicitaDados(miniDOLAR, COTACAO));
    msg_send.append(tdp.solicitaDados(miniINDICE, COTACAO));

    msg_send.append(tdp.solicitaDados(VALE, COTACAO));

    msg_send.append(tdp.solicitaDados(PETR, COTACAO));
//    msg_send.append(tdp.solicitaDados(PETR, BOOKF, BOOKDEPH));

    msg_send.append(tdp.solicitaDados(ITUB, COTACAO));
    msg_send.append(tdp.solicitaDados(BBDC, COTACAO));
    msg_send.append(tdp.solicitaDados(ABEV, COTACAO));
    msg_send.append(tdp.solicitaDados(B3SA, COTACAO));
    msg_send.append(tdp.solicitaDados(WEGE, COTACAO));
//    msg_send.append(tdp.solicitaDados(DI24, COTACAO));
//    msg_send.append(tdp.solicitaDados(DI25, COTACAO));
//    msg_send.append(tdp.solicitaDados(DI26, COTACAO));
//    msg_send.append(tdp.solicitaDados(DI27, COTACAO));
//    msg_send.append(tdp.solicitaDados(DI29, COTACAO));
//    msg_send.append(tdp.solicitaDados(DI31, COTACAO));
//    msg_send.append(tdp.solicitaDados(DI33, COTACAO));


    tcpTrydClient.write(msg_send.toLocal8Bit().constData());

}
void MainWindow::trydDisconnected()
{
    ui->textEdit_1->append("Desconectou");
}
void MainWindow::trydSocketError()
{
    ui->textEdit_1->append("Falhou");
}

//////////////////////////////////////////////////////////////////////////////

void MainWindow::on_actionMT5_Connect_triggered()
{
    if (ui->actionMT5_Connect->isChecked()) {
        tcpMt5Server = new QTcpServer(this);

        connect(tcpMt5Server, &QTcpServer::newConnection, this, &MainWindow::mt5Connected);

        if (!tcpMt5Server->listen(QHostAddress::LocalHost, 9090))
        {
            ui->textEdit_1->append("Erro ao escutar porta do MT5");
        }
        else
        {
ui->textEdit_1->append("Criando Server do MT5");
        }
    } else {
        tcpMt5Server->close();
        tcpMt5Server = nullptr;
        ui->textEdit_1->append("Fechando Server do MT5");
    }
}
void MainWindow::onSocketMt5Event()
{
    QTcpSocket *socket = static_cast<QTcpSocket*>(sender());

    QByteArray recData = socket->readAll();
    QString receivedData = QString::fromUtf8(recData);

    if (janelaInt != nullptr) janelaInt->textEditMSG->append(receivedData);

    tdp.processaDadosInt(&receivedData);

    if (!tdp.dadosCOTSp.empty())
    {
        ui->label_Sp_U->setText(QString("%1").arg(QString::number(tdp.dadosCOTSp.last().ultima, 'f', 2)));
        //        ui->label_miniDolar_V->setText(QString("%1%").arg(QString::number(tdp.dadosCOTSp.last().variacao, 'f', 2)));
    }
    if (!tdp.dadosCOTDx.empty())
    {
        ui->label_Dx_U->setText(QString("%1").arg(QString::number(tdp.dadosCOTDx.last().ultima, 'f', 2)));
        //        ui->label_Indice_V->setText(QString("%1%").arg(QString::number(tdp.dadosCOTDx.last().variacao, 'f', 2)));
    }
}
void MainWindow::mt5Connected()
{
    QTcpSocket *mt5Socket = tcpMt5Server->nextPendingConnection();
    connect(mt5Socket, SIGNAL(readyRead()), this, SLOT(onSocketMt5Event()));
    connect(mt5Socket, SIGNAL(disconnected()), mt5Socket, SLOT(deleteLater()));

    ui->textEdit_1->append("Client connected");
}

//////////////////////////////////////////////////////////////////////////////

void MainWindow::on_actionShow_TT_triggered()
{
    if (janelaTT != nullptr) return janelaTT->raise();

    janelaTT = new MyJanelaTTDialog();

    QPoint pos = this->pos();
    pos.setX(pos.x() - 440);
    janelaTT->move(pos);

    janelaTT->show();

    janelaTT->setAttribute(Qt::WA_DeleteOnClose);

    // conectar o sinal finished() ao slot que irá definir o ponteiro para nullptr
    connect(janelaTT, &QDialog::finished, this, [this]() {
        janelaTT = nullptr;
    });
}
void MainWindow::on_actionShow_Msg_triggered()
{
    if (janelaMSG != nullptr) return janelaMSG->raise();

    janelaMSG = new MyJanelaMSGDialog();

    janelaMSG->show();

    janelaMSG->setAttribute(Qt::WA_DeleteOnClose);

    // conectar o sinal finished() ao slot que irá definir o ponteiro para nullptr
    connect(janelaMSG, &QDialog::finished, this, [this]() {
        janelaMSG = nullptr;
    });
}
void MainWindow::on_actionShow_Msg_Int_triggered()
{
    if (janelaInt != nullptr) return janelaInt->raise();

    janelaInt = new MyJanelaMSGDialog();

    janelaInt->resize(200,400);
    janelaInt->show();

    janelaInt->setAttribute(Qt::WA_DeleteOnClose);

    // conectar o sinal finished() ao slot que irá definir o ponteiro para nullptr
    connect(janelaInt, &QDialog::finished, this, [this]() {
        janelaInt = nullptr;
    });
}
void MainWindow::on_actionShow_Cota_o_triggered()
{
    if (janelaCOT != nullptr) return janelaCOT->raise();

    janelaCOT = new MyJanelaMSGDialog();

    janelaCOT->resize(200,400);
    janelaCOT->show();

    janelaCOT->setAttribute(Qt::WA_DeleteOnClose);

    // conectar o sinal finished() ao slot que irá definir o ponteiro para nullptr
    connect(janelaCOT, &QDialog::finished, this, [this]() {
        janelaCOT = nullptr;
    });
}
//////////////////////////////////////////////////////////////////////////////

void MainWindow::on_actionDolar_Analiser_triggered()
{
    if (!ui->actionDolar_Analiser->isChecked())
    {
        timerAnaliser->stop();
        return;
    }
    if (chart == nullptr)
    {
        timestamp = QDateTime::currentDateTime().toMSecsSinceEpoch();

        candlestickSet = new QCandlestickSet(timestamp);
        candlestickSet->setClose(close);
        candlestickSet->setOpen(open);
        candlestickSet->setHigh(high);
        candlestickSet->setLow(low);

        deslocSeries = new QCandlestickSeries();
        deslocSeries->setIncreasingColor(QColor(Qt::green));
        deslocSeries->setDecreasingColor(QColor(Qt::red));

        deslocSeries->append(candlestickSet);

        chart = new QChart();
        chart->addSeries(deslocSeries);
        chart->createDefaultAxes();

        axisX = new QValueAxis();
        axisX->setRange(xInit , xEnd);

        axisY = new QValueAxis();
        axisY->setRange(-100 , 100);

        chart->addAxis(axisX, Qt::AlignBottom);
        chart->addAxis(axisY, Qt::AlignRight);
        chart->legend()->setVisible(false);
        chart->setMargins(QMargins(0,0,0,0));
        chart->axisX()->setGridLineVisible(false);
        chart->axisY()->setGridLineVisible(false);
        chart->setAcceptHoverEvents(true);

        deslocSeries->attachAxis(axisX);
        deslocSeries->attachAxis(axisY);

        chartView = new QChartView(chart);
        chartView->setRenderHint(QPainter::Antialiasing);
        chartView->setRubberBand(QChartView::RectangleRubberBand);
        chartView->setContentsMargins(0,0,0,0);

        lay = new QVBoxLayout;
        lay->addWidget(chartView);

        ui->widget_3->setLayout(lay);
        ui->widget_3->setContentsMargins(0,0,0,0);

        //////////////////////////////////////////////////

        timerAnaliser = new QTimer(this);
        timerAnaliser->setInterval(1000); // intervalo de 1 segundo
        QObject::connect(timerAnaliser, &QTimer::timeout, this, &MainWindow::onTimerAnaliserEvent);
    }

    lastMinute = QDateTime::currentDateTime().time().minute();
    holdTTChange = true;
    lastbook = tdp.dadosBF[DOL];
    lastTTpos = tdp.dadosTT[DOL].size() - 1;
    if (lastTTpos < 0) lastTTpos = 0;
    atualTTpos = tdp.dadosTT[DOL].size() - 1;
    if (atualTTpos < 0) atualTTpos = 0;
    timerAnaliser->start(); // inicia o timer
}
void MainWindow::onTimerAnaliserEvent()
{
    if (lastbook.empty())
    {
        lastbook = tdp.dadosBF[DOL];
        return ui->statusbar->showMessage("Book vazio", 1100);
    }
    if (tdp.dadosTT[DOL].empty()) return ui->statusbar->showMessage("TT vazio", 1100);

    //////////////////////////////////////////////////


    if ((tdp.dadosTT[DOL].size() - 1) > lastTTpos)
    {
        if (holdTTChange == true){
            atualTTpos = tdp.dadosTT[DOL].size() - 1;
            timerAnaliser->setInterval(500);
            holdTTChange = false;
            return;
        } else {
            if (atualTTpos != (tdp.dadosTT[DOL].size() - 1))
            {
                atualTTpos = tdp.dadosTT[DOL].size() - 1;
                return;
            }
        }

        ///////////////////

        int diferenca = 0;

        int negEmSpread = 0;
        int negsVendedor = 0;
        int negsComprador = 0;

        int lotesNaCompra = 0;
        int lotesNaVenda = 0;
        int saldoNaCompra = 0;
        int saldoNaVenda = 0;

        int deslocamentoNaCompra = 0;
        int deslocamentoNaVednda = 0;
        int lotesNaVendaMedio = 0;
        int lotesNaCompraMedio = 0;

        int deslocamentoBookAsk = 0;
        int deslocamentoBookBid = 0;

        atualbook = tdp.dadosBF[DOL];

        ///////////////////

        for (int i = lastTTpos + 1; i <= atualTTpos; i++)
        {
            if (tdp.dadosTT[DOL][i].preco <= lastbook[0].precoComprador){
                if (tdp.dadosTT[DOL][i].Agressor == "Comprador"){
                    negsVendedor += tdp.dadosTT[DOL][i].lote;
                }else if (tdp.dadosTT[DOL][i].Agressor == "Vendedor"){
                    negsVendedor += tdp.dadosTT[DOL][i].lote;
                }
            }else if (tdp.dadosTT[DOL][i].preco >= lastbook[0].precoVendedor){
                if (tdp.dadosTT[DOL][i].Agressor == "Vendedor"){
                    negsComprador += tdp.dadosTT[DOL][i].lote;
                }else if (tdp.dadosTT[DOL][i].Agressor == "Comprador"){
                    negsComprador += tdp.dadosTT[DOL][i].lote;
                }
            }else{
                negEmSpread++;
            }
        }

        ///////////////////

        deslocamentoBookBid = (int)(2 * (lastbook[0].precoComprador - atualbook[0].precoComprador));
        deslocamentoBookAsk = (int)(2 * (atualbook[0].precoVendedor - lastbook[0].precoVendedor));

        ///////////////////

        if (deslocamentoBookBid > BOOKDEPH) deslocamentoBookBid = BOOKDEPH;
        if (deslocamentoBookAsk > BOOKDEPH) deslocamentoBookAsk = BOOKDEPH;

        if (deslocamentoBookBid >= 0)
        {
            for (int j = 0; j < deslocamentoBookBid; j++)
            {
                lotesNaCompra += lastbook[j].loteComprador;
            }
            lotesNaCompraMedio = lotesNaCompra;

            if (deslocamentoBookBid > 0) lotesNaCompraMedio = lotesNaCompraMedio / deslocamentoBookBid;

            saldoNaCompra = lotesNaCompra - negsVendedor;
            deslocamentoNaVednda = atualbook[0].loteComprador - saldoNaCompra - (deslocamentoBookBid * lotesNaCompraMedio);
            totalDeslocamentoV += deslocamentoNaVednda;
        }

        if (deslocamentoBookAsk >= 0)
        {
            for (int j = 0; j < deslocamentoBookAsk; j++)
            {
                lotesNaVenda += lastbook[j].loteVendedor;
            }
            lotesNaVendaMedio = lotesNaVenda;

            if (deslocamentoBookAsk > 0) lotesNaVendaMedio = lotesNaVendaMedio / deslocamentoBookAsk;

            saldoNaVenda = lotesNaVenda - negsComprador;
            deslocamentoNaCompra = atualbook[0].loteVendedor - saldoNaVenda - (deslocamentoBookAsk * lotesNaVendaMedio);
            totalDeslocamentoC += deslocamentoNaCompra;
        }

        diferenca = totalDeslocamentoV - totalDeslocamentoC;

        /////////////////////////////////////////////////////////

        close = diferenca;
        if (diferenca > high) high = diferenca;
        if (high > highhigh)
        {
            highhigh = 100*round(high/100) + 100;
            axisY->setMax(highhigh);
        }
        if (diferenca < low) low = diferenca;
        if (low < lowlow)
        {
            lowlow = 100*round(low/100) - 100;
            axisY->setMin(lowlow);
        }

        int currentMinute = QDateTime::currentDateTime().time().minute();
        if(lastMinute != currentMinute)
        {
            lastMinute = currentMinute;

            open = diferenca;
            high = diferenca;
            low = diferenca;
            close = diferenca;
            timestamp = QDateTime::currentDateTime().toMSecsSinceEpoch();

            candlestickSet = new QCandlestickSet();
            candlestickSet->setTimestamp(timestamp);
            candlestickSet->setOpen(open);
            candlestickSet->setHigh(high);
            candlestickSet->setLow(low);
            candlestickSet->setClose(close);

            deslocSeries->append(candlestickSet);

            if (deslocSeries->count() >= 55)
            {
                axisX->setRange(xInit++ , xEnd++);
            }
        }
        else
        {
            candlestickSet->setHigh(high);
            candlestickSet->setLow(low);
            candlestickSet->setClose(close);
        }

        ///////////////////

        lastbook = atualbook;
        lastTTpos = atualTTpos;
        timerAnaliser->setInterval(1000);
        holdTTChange = true;
    }

}

//////////////////////////////////////////////////////////////////////////////

void MainWindow::on_actionAnalisador_de_Leil_o_triggered()
{
    //////////////////////////////////////////////////

    timerLeilao = new QTimer(this);
    timerLeilao->setInterval(1000); // intervalo de 1 segundo
    QObject::connect(timerLeilao, &QTimer::timeout, this, &MainWindow::onTimerLeilaoEvent);
}

void MainWindow::onTimerLeilaoEvent(){

    bookleilao = tdp.dadosBF[PETR4];


}



