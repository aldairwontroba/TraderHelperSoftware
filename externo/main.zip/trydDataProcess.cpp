#include "trydDataProcess.h"



QString trydDataProcess::solicitaDados(QString ativo, QString tipo, int pBoff)
{
    QString msg_retorno;

    if (tipo == "NEGS$S|")
    {
        msg_retorno = tipo + ativo + "#";
    }

    if (tipo == "LVL2$S|")
    {
        for (int j = 0; j < pBoff; j++)
        {
            for (int i = 1; i <= 4; i++)
            {
                msg_retorno.append(QString("%1|%2|%3|%4#").arg((tipo+"1"),ativo,QString::number(j),QString::number(i)));
            }
        }
    }

    if (tipo == "COT$S|")
    {
        msg_retorno = tipo + ativo + "#";
    }

    return msg_retorno;
}

QVector<bool> trydDataProcess::processaDados(QString* msg)
{
    QVector<bool> posicoesModificadas(tamAtivo, 0);

    size_t pos_s;
    size_t pos_e;

    pos_s = msg->indexOf("NEGS");

    while (pos_s != -1)
    {
        pos_e = msg->indexOf('#',pos_s + 1);
        QString negs_copia = msg->mid(pos_s, pos_e - pos_s);
        SeparadorDadosResult resultado = separador_dados_TT(&negs_copia);
        sizeTTChange[resultado.ativo] = resultado.sizeChange;
        posicoesModificadas[resultado.ativo] = true;
        pos_s = msg->indexOf("NEGS", pos_s  + 1);
    }

    pos_s = msg->indexOf("LVL2");

    while (pos_s != -1)
    {
        pos_e = msg->indexOf('#', pos_s + 1);
        QString lvl2_copia = msg->mid(pos_s, pos_e - pos_s);
        separador_dados_BK(&lvl2_copia);
        pos_s = msg->indexOf("LVL2", pos_s  + 1);
    }

    pos_s = msg->indexOf("COT");

    while (pos_s != -1)
    {
        pos_e = msg->indexOf('#', pos_s + 1);
        QString cot_copia = msg->mid(pos_s, pos_e - pos_s);
        separador_dados_COT(&cot_copia);
        pos_s = msg->indexOf("COT", pos_s  + 1);
    }

    return posicoesModificadas;
}

SeparadorDadosResult trydDataProcess::separador_dados_TT(QString* msg)
{
    struct dataTTaux {
        QVector<int> negocio;
        QVector<QString> datetime;
        QVector<double> preco;
        QVector<int> lote;
        QVector<int> Ag_comprador;
        QVector<int> Ag_vendedor;
        QVector<QString> Agressor;
    };

    dataTTaux ttAux;

    dataTT datattAux;
    QVector<dataTT> ttUpdate;

    QString stgDataTT;
    size_t posStartIn;
    size_t posStartOut;
    size_t posEndIn;
    size_t posEndOut;

    int sizeCheck[7] = { 0,0,0,0,0,0,0 };

    // Ativo + tamanho
    QString stgAtivo;
    stgAtivo = msg->mid(5, 5); //Copia o ativo
    Ativos ativo = ativoToNum(stgAtivo);

    //Decodificação da wxString NEGS

    // Obtem dados de negocio ------------------------------------------------------------------------------------------
    posStartOut = msg->indexOf('|'); //Encontra 1° separador
    posEndOut = msg->indexOf('|', posStartOut + 1); //Encontra 2° separador
    stgDataTT = msg->mid(posStartOut + 1, posEndOut - posStartOut - 1); //Copia a String entre os separadores
    posStartIn = 0;
    do { //executa um loop para capturar todos os dados de negocio da String entre | (loop In)
        posEndIn = stgDataTT.indexOf('@', posStartIn); //Encontra o 1° dado de negocio
        if (posEndIn == -1) posEndIn = stgDataTT.length(); //se -1, então não há mais dados
        QString strAux = stgDataTT.mid(posStartIn, posEndIn - posStartIn); //copia a wxString
        int valueAux = strAux.toInt(); //converte string para int
        ttAux.negocio.push_back(valueAux); //salva negocio
        posStartIn = posEndIn + 1; //posiçao inicial + 1 para remover o @
        sizeCheck[0]++;
    } while (posEndIn != stgDataTT.length());


    // Obtem dados de hora ------------------------------------------------------------------------------------------
    posStartOut = posEndOut;
    posEndOut = msg->indexOf('|', posStartOut + 1);
    stgDataTT = msg->mid(posStartOut + 1, posEndOut - posStartOut - 1);
    posStartIn = 0;
    do {
        posEndIn = stgDataTT.indexOf('@', posStartIn);
        if (posEndIn == -1) posEndIn = stgDataTT.length();
        QString strAux = stgDataTT.mid(posStartIn, posEndIn - posStartIn); //copia a wxString
        ttAux.datetime.push_back(strAux); //salva dataTime como string
        posStartIn = posEndIn + 1;
        sizeCheck[1]++;
    } while (posEndIn != stgDataTT.length());


    // Obtem dados de preco ------------------------------------------------------------------------------------------
    posStartOut = posEndOut;
    posEndOut = msg->indexOf('|', posStartOut + 1);
    stgDataTT = msg->mid(posStartOut + 1, posEndOut - posStartOut - 1);
    posStartIn = 0;
    do {
        posEndIn = stgDataTT.indexOf('@', posStartIn);
        if (posEndIn == -1) posEndIn = stgDataTT.length();
        QString strAux = stgDataTT.mid(posStartIn, posEndIn - posStartIn); //copia a wxString
        strAux.remove(strAux.indexOf('.'), 1);
        strAux.replace(',', '.');
        double valueAux = strAux.toDouble();
        ttAux.preco.push_back(valueAux); //salva dataTime como string
        sizeCheck[2]++;
        posStartIn = posEndIn + 1;
    } while (posEndIn != stgDataTT.length());


    // Obtem dados de lote ------------------------------------------------------------------------------------------
    posStartOut = posEndOut;
    posEndOut = msg->indexOf('|', posStartOut + 1);
    stgDataTT = msg->mid(posStartOut + 1, posEndOut - posStartOut - 1);
    posStartIn = 0;
    do {
        posEndIn = stgDataTT.indexOf('@', posStartIn); //Encontra o 1° dado de negocio
        if (posEndIn == -1) posEndIn = stgDataTT.length(); //se -1, então não há mais dados
        QString strAux = stgDataTT.mid(posStartIn, posEndIn - posStartIn); //copia a wxString
        int valueAux = strAux.toInt(); //converte string para long
        ttAux.lote.push_back(valueAux); //salva negocio
        posStartIn = posEndIn + 1; //posiçao inicial + 1 para remover o @
        sizeCheck[3]++;
    } while (posEndIn != stgDataTT.length());


    // Obtem dados de Agente Comprador ------------------------------------------------------------------------------------------
    posStartOut = posEndOut;
    posEndOut = msg->indexOf('|', posStartOut + 1);
    stgDataTT = msg->mid(posStartOut + 1, posEndOut - posStartOut - 1);
    posStartIn = 0;
    do {
        posEndIn = stgDataTT.indexOf('@', posStartIn); //Encontra o 1° dado de negocio
        if (posEndIn == -1) posEndIn = stgDataTT.length(); //se -1, então não há mais dados
        QString strAux = stgDataTT.mid(posStartIn, posEndIn - posStartIn); //copia a wxString
        long valueAux = strAux.toInt(); //converte string para long
        ttAux.Ag_comprador.push_back(valueAux); //salva negocio
        posStartIn = posEndIn + 1; //posiçao inicial + 1 para remover o @
        sizeCheck[4]++;
    } while (posEndIn != stgDataTT.length());


    // Obtem dados de Agente Vendedor ------------------------------------------------------------------------------------------
    posStartOut = posEndOut;
    posEndOut = msg->indexOf('|', posStartOut + 1);
    stgDataTT = msg->mid(posStartOut + 1, posEndOut - posStartOut - 1);
    posStartIn = 0;
    do {
        posEndIn = stgDataTT.indexOf('@', posStartIn); //Encontra o 1° dado de negocio
        if (posEndIn == -1) posEndIn = stgDataTT.length(); //se -1, então não há mais dados
        QString strAux = stgDataTT.mid(posStartIn, posEndIn - posStartIn); //copia a wxString
        long valueAux = strAux.toInt(); //converte string para long
        ttAux.Ag_vendedor.push_back(valueAux); //salva negocio
        posStartIn = posEndIn + 1; //posiçao inicial + 1 para remover o @
        sizeCheck[5]++;
    } while (posEndIn != stgDataTT.length());


    // Obtem dados de Agressor ------------------------------------------------------------------------------------------
    posStartOut = posEndOut;
    posEndOut = msg->length();
    stgDataTT = msg->mid(posStartOut + 1, posEndOut - posStartOut - 1);
    posStartIn = 0;
    do {
        posEndIn = stgDataTT.indexOf('@', posStartIn);
        if (posEndIn == -1) posEndIn = stgDataTT.length();
        QString strAux = stgDataTT.mid(posStartIn, posEndIn - posStartIn); //copia a wxString
        ttAux.Agressor.push_back(strAux); //salva Agressor como string
        posStartIn = posEndIn + 1;
        sizeCheck[6]++;
    } while (posEndIn != stgDataTT.length());

    for (int i = 0; i < 6; i++) //verifica se foi recebido corretamente o numero de dados
    {
        if (sizeCheck[i] != sizeCheck[i + 1])
        {
            SeparadorDadosResult saida;
            saida.ativo = ativo;
            saida.sizeChange = -1;
            return saida;
        }
    }

    for (int i = 0; i < sizeCheck[0]; i++)
    {
        datattAux.negocio = ttAux.negocio[i];
        datattAux.datetime = ttAux.datetime[i];
        datattAux.preco = ttAux.preco[i];
        datattAux.lote = ttAux.lote[i];
        datattAux.Ag_comprador = ttAux.Ag_comprador[i];
        datattAux.Ag_vendedor = ttAux.Ag_vendedor[i];
        datattAux.Agressor = ttAux.Agressor[i];

        ttUpdate.push_back(datattAux);
    }


    dadosTT[ativo].append(ttUpdate);

    SeparadorDadosResult saida;
    saida.ativo = ativo;
    saida.sizeChange = sizeCheck[0];
    return saida;
}

QString trydDataProcess::getPrintTT(int sizeChange, int ativo) {

    QString msg_print;

    if (sizeChange >= 1)
    {
        int sizeDadosTT = dadosTT[ativo].size();

        msg_print.append(QString("%1").arg(dadosTT[ativo][sizeDadosTT - sizeChange].datetime));
        msg_print.append(QString("	 %1").arg(dadosTT[ativo][sizeDadosTT - sizeChange].lote));
        msg_print.append(QString("	 %1").arg(QString::number(dadosTT[ativo][sizeDadosTT - sizeChange].preco, 'f', 2)));
        msg_print.append(QString("	 %1").arg(dadosTT[ativo][sizeDadosTT - sizeChange].Agressor));

        for (int i = 1; i < sizeChange; i++)
        {
            msg_print.append(QString("\n%1").arg(dadosTT[ativo][sizeDadosTT - sizeChange + i].datetime));
            msg_print.append(QString("	 %1").arg(dadosTT[ativo][sizeDadosTT - sizeChange + i].lote));
            msg_print.append(QString("	 %1").arg(QString::number(dadosTT[ativo][sizeDadosTT - sizeChange + i].preco, 'f', 2)));
            msg_print.append(QString("	 %1").arg(dadosTT[ativo][sizeDadosTT - sizeChange + i].Agressor));
        }
    }
    if (sizeChange == -1)
    {
        msg_print.append(QString("\n Erro na separação de dados do TT"));
    }

    return msg_print;
}

int trydDataProcess::separador_dados_BK(QString* msg)
{
    QVector<dataBOOKF> dadosBFaux;

    QString stgDataBF;
    size_t posStartIn;
    size_t posStartOut;
    size_t posEndIn;
    size_t posEndOut;
    unsigned int profundidade = 0;


    // Ativo + tamanho
    QString stgAtivo;
    stgAtivo = msg->mid(5, 5); //Copia o ativo
    Ativos ativo = ativoToNum(stgAtivo);
    if (dadosBF[ativo].empty()) return -1;
    dadosBFaux.resize(dadosBF[ativo].size());

    //Decodificação da wxString LVL2
    posStartOut = msg->indexOf('|'); //Encontra 1° separador

    do {
        QString strAux;
        int largura = 0;

        posEndOut = msg->indexOf('|', posStartOut + 1); //Encontra 2° separador
        if (posEndOut == -1) posEndOut = msg->length(); //se -1, então não há mais dados

        stgDataBF = msg->mid(posStartOut + 3, posEndOut - posStartOut - 3); //Copia a String entre os separadores

        posStartIn = 0;
        posEndIn = stgDataBF.indexOf(';', posStartIn); //Encontra o 1° dado de negocio
        strAux = stgDataBF.mid(posStartIn, posEndIn - posStartIn); //copia a wxString
        profundidade = strAux.toInt();

        posStartIn = posEndIn + 1;
        posEndIn = stgDataBF.indexOf(';', posStartIn); //Encontra o 1° dado de negocio
        strAux = stgDataBF.mid(posStartIn, posEndIn - posStartIn); //copia a wxString
        largura = strAux.toInt();

        posStartIn = posEndIn + 1;
        posEndIn =stgDataBF.length();
        strAux = stgDataBF.mid(posStartIn, posEndIn - posStartIn); //copia a wxString
        strAux.replace(',', '.');
        double valueAux = strAux.toDouble();

        switch (largura)
        {
        case 1:
            dadosBFaux[profundidade].loteComprador = (int)valueAux;
        break;

        case 2:
            dadosBFaux[profundidade].precoComprador= valueAux;
        break;

        case 3:
            dadosBFaux[profundidade].precoVendedor = valueAux;
        break;

        case 4:
            dadosBFaux[profundidade].loteVendedor = (int)valueAux;
        break;
        }

        posStartOut = posEndOut;

    } while (posEndOut != msg->length());

    // /////////////////////////////////


    dadosBF[ativo] = dadosBFaux;

    return 0;
}

QString trydDataProcess::getPrintBF(int deeph, int ativo) {

    QString msg_print;

    if (dadosBF[ativo].empty()) return msg_print.append(QString("\n Book vazio"));

    if (deeph > dadosBF[ativo].size()) deeph = dadosBF[ativo].size();

    msg_print.append(QString("\n--------------------------------------------------\n"));
    for (int i = 0; i < deeph; i++)
    {
        msg_print.append(QString("%1	").arg(dadosBF[ativo][i].loteComprador));
        msg_print.append(QString("%1	").arg(QString::number(dadosBF[ativo][i].precoComprador, 'f', 2)));
        msg_print.append(QString("%1	").arg(QString::number(dadosBF[ativo][i].precoVendedor, 'f', 2)));
        msg_print.append(QString("%1 \n").arg(dadosBF[ativo][i].loteVendedor));
    }

    return msg_print;
}

int trydDataProcess::separador_dados_COT(QString* msg)
{
/*
 *COT!PETR4|29,63 |0,00|300|29,00|29,00|100|0,00|0,00|0,00|29,63|0|10:11:58|0|0|0,00|0|0|Leilão||100|||0,00|0,00 (0,00%)|14/07/2023|14/07/2023 10:11|PETROBRAS PN N2||=|0,44|0,33|43,34|-1,56|72,56|74,39|151,74|29,00|232900|10:05:00         ||0|0|0|-130444969|5602042788|0|0|0|0|0|0|0|0|0|0,00|0,00|0,00|0,00|0,00|0,00|41400|C|0|0|0|0|0|0|0|0|0|0,00|0,00|0,00|0,00|0,00|0,00|0|0|0|0|0|0|0|0|0|0|6,4825|100#
 *COT!PETR4|Ultima|0,00|300|29,00|29,00|100|0,00|0,00|0,00|29,63|0|10:11:58|0|0|0,00|0|0|Leilão||100|||0,00|0,00 (0,00%)|14/07/2023|14/07/2023 10:11|PETROBRAS PN N2||=|0,44|0,33|43,34|-1,56|72,56|74,39|151,74|29,00|232900|Horario do leilao||0|0|0|-130444969|5602042788|0|0|0|0|0|0|0|0|0|0,00|0,00|0,00|0,00|0,00|0,00|41400|C|0|0|0|0|0|0|0|0|0|0,00|0,00|0,00|0,00|0,00|0,00|0|0|0|0|0|0|0|0|0|0|6,4825|100#
 *
 *
*/

    dataCOT auxCOT;
    QString aux;
    size_t posStart;
    size_t posEnd;


    QString stgAtivo;
    stgAtivo = msg->mid(4, 5); //copia a wxString (ATIVO)


    // inicia a separação da informação
    // ultima
    posStart = msg->indexOf('|'); //Encontra 1° separador
    posEnd = msg->indexOf('|', posStart + 1); //Encontra 2° separador
    aux = msg->mid(posStart + 1, posEnd - posStart - 1);
    aux.remove('.');
    aux.replace(',', '.');
    auxCOT.ultima = aux.toDouble();

    //variacao
    posStart = posEnd;
    posEnd = msg->indexOf('|', posStart + 1);
    aux = msg->mid(posStart + 1, posEnd - posStart - 1);
    aux.remove('.');
    aux.replace(',', '.');
    auxCOT.variacao = aux.toDouble();

    //bid_lote
    posStart = posEnd;
    posEnd = msg->indexOf('|', posStart + 1);
    aux = msg->mid(posStart + 1, posEnd - posStart - 1);
    auxCOT.bid_lote = aux.toInt();

    //bid
    posStart = posEnd;
    posEnd = msg->indexOf('|', posStart + 1);
    aux = msg->mid(posStart + 1, posEnd - posStart - 1);
    aux.remove('.');
    aux.replace(',', '.');
    auxCOT.bid = aux.toDouble();

    //ask
    posStart = posEnd;
    posEnd = msg->indexOf('|', posStart + 1);
    aux = msg->mid(posStart + 1, posEnd - posStart - 1);
    aux.remove('.');
    aux.replace(',', '.');
    auxCOT.ask = aux.toDouble();

    //ask_lote
    posStart = posEnd;
    posEnd = msg->indexOf('|', posStart + 1);
    aux = msg->mid(posStart + 1, posEnd - posStart - 1);
    auxCOT.ask_lote = aux.toInt();

    //abertura
    posStart = posEnd;
    posEnd = msg->indexOf('|', posStart + 1);
    aux = msg->mid(posStart + 1, posEnd - posStart - 1);
    aux.remove('.');
    aux.replace(',', '.');
    auxCOT.abertura = aux.toDouble();

    //maxima
    posStart = posEnd;
    posEnd = msg->indexOf('|', posStart + 1);
    aux = msg->mid(posStart + 1, posEnd - posStart - 1);
    aux.remove('.');
    aux.replace(',', '.');
    auxCOT.maxima = aux.toDouble();

    //minima
    posStart = posEnd;
    posEnd = msg->indexOf('|', posStart + 1);
    aux = msg->mid(posStart + 1, posEnd - posStart - 1);
    aux.remove('.');
    aux.replace(',', '.');
    auxCOT.minima = aux.toDouble();

    //fechamento
    posStart = posEnd;
    posEnd = msg->indexOf('|', posStart + 1);
    aux = msg->mid(posStart + 1, posEnd - posStart - 1);
    aux.remove('.');
    aux.replace(',', '.');
    auxCOT.fechamento = aux.toDouble();

    //volume
    posStart = posEnd;
    posEnd = msg->indexOf('|', posStart + 1);
    aux = msg->mid(posStart + 1, posEnd - posStart - 1);
    auxCOT.volume = aux.toDouble();

    //hora
    posStart = posEnd;
    posEnd = msg->indexOf('|', posStart + 1);
    aux = msg->mid(posStart + 1, posEnd - posStart - 1);
    auxCOT.hora = aux;

    //status
    posStart = posEnd;
    for (int i=0;i<=4;i++)
        posStart = msg->indexOf('|', posStart + 1);
    posEnd = msg->indexOf('|', posStart + 1);
    aux = msg->mid(posStart + 1, posEnd - posStart - 1);
    auxCOT.estatus = aux;

    //variacao_p // |Leilão||100|||0,00|0,00 (0,00%)|
    posStart = posEnd;
    for (int i=0;i<=3;i++)
        posStart = msg->indexOf('|', posStart + 1);
    posEnd = msg->indexOf('|', posStart + 1);
    aux = msg->mid(posStart + 1, posEnd - posStart - 1);
    aux.replace(',', '.');
    auxCOT.variacao_p = aux.toDouble();

    //horario_leilao
    posStart = posEnd;
    for (int i=0;i<=14;i++)
        posStart = msg->indexOf('|', posStart + 1);
    posEnd = msg->indexOf('|', posStart + 1);
    aux = msg->mid(posStart + 1, posEnd - posStart - 1);
    auxCOT.horario_leilao = aux;


    Ativos ativo = ativoToNum(stgAtivo);

    dadosCOT[ativo] = auxCOT;

    return 0;
}

QString trydDataProcess::getPrintCOT(int ativo){

    QString msg_print;

    msg_print.append(QString("\n--------------------------------------------------\n"));

    msg_print.append(QString("Ultima: %1 \n").arg(QString::number(dadosCOT[ativo].ultima, 'f', 2)));
    msg_print.append(QString("Variação: %1 \n").arg(QString::number(dadosCOT[ativo].variacao, 'f', 2)));
    msg_print.append(QString("bid_lote: %1 \n").arg(dadosCOT[ativo].bid_lote));
    msg_print.append(QString("bid: %1 \n").arg(QString::number(dadosCOT[ativo].bid, 'f', 2)));
    msg_print.append(QString("ask: %1 \n").arg(QString::number(dadosCOT[ativo].ask, 'f', 2)));
    msg_print.append(QString("ask_lote: %1 \n").arg(dadosCOT[ativo].ask_lote));
    msg_print.append(QString("abertura: %1 \n").arg(QString::number(dadosCOT[ativo].abertura, 'f', 2)));
    msg_print.append(QString("maxima: %1 \n").arg(QString::number(dadosCOT[ativo].maxima, 'f', 2)));
    msg_print.append(QString("minima: %1 \n").arg(QString::number(dadosCOT[ativo].minima, 'f', 2)));
    msg_print.append(QString("fechamento: %1 \n").arg(QString::number(dadosCOT[ativo].fechamento, 'f', 2)));
    msg_print.append(QString("volume: %1 \n").arg(QString::number(dadosCOT[ativo].volume, 'f', 2)));
    msg_print.append("hora:"+dadosCOT[ativo].hora);
    msg_print.append("\nEstatus: "+dadosCOT[ativo].estatus);
    msg_print.append(QString("\nvariacao_p: %1 \n").arg(QString::number(dadosCOT[ativo].variacao_p, 'f', 2)));
    msg_print.append("Horario do Leilão: "+dadosCOT[ativo].horario_leilao);

    return msg_print;
}

QVector<trydDataProcess::dataBOOKF> trydDataProcess::getBook(int deeph, int ativo)
{
    return dadosBF[ativo];
}

int trydDataProcess::processaDadosInt(QString* msg)
{
    QString stgData;
    struct dataCOTString {
        QString ultima;
        QString variacao;
    };
    dataCOTString stgAux;
    dataCOTint Aux;
    size_t posStartOut;
    size_t posEndOut;

    stgData = msg->mid(0, 4); //copia a wxString

    posStartOut = msg->indexOf(':'); //Encontra 1° separador
    posEndOut = msg->indexOf('.'); //Encontra 2° separador
    stgAux.ultima = msg->mid(posStartOut + 2, posEndOut + 4 - posStartOut - 2);

    Aux.ultima = stgAux.ultima.toDouble();
//    Aux.variacao = stgAux.variacao.toDouble();

    if (stgData == "GOLD") {
        dadosCOTOuro.push_back(Aux);
    }
    else if (stgData == "USDI") {
        dadosCOTDx.push_back(Aux);
    }
    else if (stgData == "Usa5") {
        dadosCOTSp.push_back(Aux);
    }
    else if (stgData == "LCru") {
        dadosCOTWti.push_back(Aux);
    }

    return 0;
}
